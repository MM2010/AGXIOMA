﻿---
slug: art155quinquies
title: Art. 155 quinquies codice civile - Disposizioni in favore dei figli maggiorenni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo V - Dello scioglimento del matrimonio e della separazione dei coniugi Articolo abrogato dall&#39;art. 106, comma 1, lett. a), D.Lgs. 28 dicembre 2013, n. 154. &lsqb;Il giudice, valutate le circostanze, pu&ograve; disporre in favore dei figli maggiorenni non indipendenti economicamente il pagamento di un assegno periodico. Tale assegno, salvo diversa determinazione del giudice, &egrave; versato direttamente all&#39;avente diritto.Ai figli maggiorenni portatori di handicap grave ai sensi dell&#39;articolo 3, comma 3, della legge 5 febbraio 1992, n. 104, si applicano integralmente le disposizioni previste in favore dei figli minori.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni