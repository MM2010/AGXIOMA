﻿---
slug: art1117quater
title: Art. 1117 quater codice civile - Tutela delle destinazioni d'uso - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO TERZO - Della proprietà &rarr; Titolo VII - Della comunione &rarr; Capo II - Del condominio negli edifici (1)In caso di attivit&agrave; che incidono negativamente e in modo sostanziale sulle destinazioni d&#39;uso delle parti comuni, l&#39;amministratore o i condomini, anche singolarmente, possono diffidare l&#39;esecutore e possono chiedere la convocazione dell&rsquo;assemblea per far cessare la violazione, anche mediante azioni giudiziarie. L&#39;assemblea delibera in merito alla cessazione di tali attivit&agrave; con la maggioranza prevista dal secondo comma dell&#39;articolo 1136(2). Art. precedenteprec. Art. successivosucc.