﻿---
slug: art14
title: Art. 14 codice civile - Atto costitutivo - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Le associazioni e le fondazioni devono essere costituite [16] con atto pubblico [2699] [3].La fondazione pu&ograve; essere disposta anche con testamento. Art. precedenteprec. Art. successivosucc.