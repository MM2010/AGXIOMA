﻿---
slug: art13
title: Art. 13 codice civile - Società - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo I - Disposizioni generali Le societ&agrave; sono regolate dalle disposizioni contenute nel libro V [2200, 2247, 2331, 2463, 2523, 99 e ss. disp. att.]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni