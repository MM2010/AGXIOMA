﻿---
slug: art33
title: Art. 33 codice civile - Registrazione delle persone giuridiche - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Articolo abrogato dall&#39; art. 11, lett. d), d.P.R. 10 febbraio 2000, n. 361. &lsqb;In ogni provincia &egrave; istituito un pubblico registro delle persone giuridiche.Nel registro devono indicarsi la data dell&#39;atto costitutivo e quella del decreto di riconoscimento, la denominazione, lo scopo, il patrimonio, la durata, qualora sia stata determinata, la sede della persona giuridica e il cognome e il nome degli amministratori con la menzione di quelli ai quali &egrave; attribuita la rappresentanza.La registrazione pu&ograve; essere disposta anche d&#39;ufficio.Gli amministratori di un&#39;associazione o di una fondazione non registrata, bench&eacute; riconosciuta, rispondono personalmente e solidalmente, insieme con la persona giuridica, delle obbligazioni assunte.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni