﻿---
slug: art337quinquies
title: Art. 337 quinquies codice civile - Revisione delle disposizioni concernenti l'affidamento dei figli - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX - Della responsabilità genitoriale e dei diritti e doveri del figlio &rarr; Capo II - Esercizio della responsabilità genitoriale a seguito di separazione, scioglimento, cessazione degli effetti civili, annullamento, nullità del matrimonio ovvero all'esito di procedimenti relativi ai figli nati fuori del matrimonio (1)I genitori hanno diritto di chiedere in ogni tempo la revisione delle disposizioni concernenti l&#39;affidamento dei figli, l&#39;attribuzione dell&#39;esercizio della responsabilit&agrave; genitoriale su di essi e delle eventuali disposizioni relative alla misura e alla modalit&agrave; del contributo. Art. precedenteprec. Art. successivosucc.