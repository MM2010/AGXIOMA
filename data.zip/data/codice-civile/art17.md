﻿---
slug: art17
title: Art. 17 codice civile - Acquisto di immobili e accettazione di donazioni, eredità e legati - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Questo articolo &egrave; stato abrogato dall&#39;art. 13, L. 15 maggio 1997, n. 127. &lsqb;La persona giuridica non pu&ograve; acquistare beni immobili, n&eacute; accettare donazioni o eredit&agrave;, n&eacute; conseguire legati senza l&#39;autorizzazione governativa.Senza questa autorizzazione l&#39;acquisto e l&#39;accettazione non hanno effetto.&rsqb; Art. precedenteprec. Art. successivosucc.