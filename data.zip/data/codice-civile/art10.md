﻿---
slug: art10
title: Art. 10 codice civile - Abuso dell'immagine altrui - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo I - Delle persone fisiche Qualora l&#39;immagine di una persona o dei genitori, del coniuge o dei figli sia stata esposta o pubblicata fuori dei casi in cui l&#39;esposizione o la pubblicazione &egrave; dalla legge consentita, ovvero con pregiudizio al decoro o alla reputazione della persona stessa o dei detti congiunti, l&#39;autorit&agrave; giudiziaria, su richiesta dell&#39;interessato, pu&ograve; disporre che cessi l&#39;abuso, salvo il risarcimento dei danni(1). Art. precedenteprec. Art. successivosucc.