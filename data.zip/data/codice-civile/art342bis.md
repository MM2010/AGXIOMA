﻿---
slug: art342bis
title: Art. 342 bis codice civile - Ordini di protezione contro gli abusi familiari - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX bis - Ordini di protezione contro gli abusi familiari Titolo abrogato dal D.Lgs. 31 ottobre 2024, n. 164 &lsqb;(0)(1)Quando la condotta del coniuge o di altro convivente &egrave; causa di grave pregiudizio all&#39;integrit&agrave; fisica o morale ovvero alla libert&agrave; dell&#39;altro coniuge o convivente, il giudice, [qualora il fatto non costituisca reato perseguibile d&#39;ufficio,](2) su istanza di parte [736 bis ss. c.p.c.], pu&ograve; adottare con decreto uno o pi&ugrave; dei provvedimenti di cui all&#39;articolo 342 ter(3).&rsqb; Art. precedenteprec. Art. successivosucc.