﻿---
slug: art20
title: Art. 20 codice civile - Convocazione dell'assemblea delle associazioni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni L&#39;assemblea delle associazioni deve essere convocata dagli amministratori una volta l&#39;anno per l&#39;approvazione del bilancio.L&#39;assemblea deve essere inoltre convocata quando se ne ravvisa la necessit&agrave; o quando ne &egrave; fatta richiesta motivata da almeno un decimo degli associati. In questo ultimo caso, se gli amministratori non vi provvedono, la convocazione pu&ograve; essere ordinata dal presidente del tribunale [8]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo