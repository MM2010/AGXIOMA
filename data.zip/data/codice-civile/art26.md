﻿---
slug: art26
title: Art. 26 codice civile - Coordinamento di attività e unificazione di amministrazione - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni L&#39;autorit&agrave; governativa pu&ograve; disporre il coordinamento dell&#39;attivit&agrave; di pi&ugrave; fondazioni ovvero l&#39;unificazione della loro amministrazione, rispettando, per quanto &egrave; possibile, la volont&agrave; del fondatore [28, co. 3]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo