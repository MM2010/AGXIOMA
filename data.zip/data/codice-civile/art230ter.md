﻿---
slug: art230ter
title: Art. 230 ter codice civile - Diritti del convivente - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo VI - Del regime patrimoniale della famiglia &rarr; Sezione VI - Dell'impresa familiare Al convivente di fatto che presti stabilmente la propria opera all&#39;interno dell&#39;impresa dell&#39;altro convivente spetta una partecipazione agli utili dell&#39;impresa familiare ed ai beni acquistati con essi nonch&eacute; agli incrementi dell&#39;azienda, anche in ordine all&#39;avviamento, commisurata al lavoro prestato. Il diritto di partecipazione non spetta qualora tra i conviventi esista un rapporto di societ&agrave; o di lavoro subordinato(1)(2). Art. precedenteprec. Art. successivosucc.