﻿---
slug: art12
title: Art. 12 codice civile - Persone giuridiche private - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo I - Disposizioni generali L&#39;articolo in esame &egrave; stato abrogato dall&#39;art. 11, comma I, lett. a), D.P.R. 10 febbraio 2000, n. 361. &lsqb;Le associazioni, le fondazioni e le altre istituzioni di carattere privato acquistano la personalit&agrave; giuridica mediante il riconoscimento concesso con decreto del Presidente della Repubblica. Per determinate categorie di enti che esercitano la loro attivit&agrave; nell&#39;ambito della provincia, il Governo pu&ograve; delegare ai prefetti la facolt&agrave; di riconoscerli con loro decreto.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF