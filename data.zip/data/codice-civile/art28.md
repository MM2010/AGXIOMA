﻿---
slug: art28
title: Art. 28 codice civile - Trasformazione delle fondazioni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Quando lo scopo &egrave; esaurito o divenuto impossibile o di scarsa utilit&agrave;, o il patrimonio &egrave; divenuto insufficiente, l&#39;autorit&agrave; governativa, anzich&eacute; dichiarare estinta la fondazione, pu&ograve; provvedere alla sua trasformazione, allontanandosi il meno possibile dalla volont&agrave; del fondatore [16, 27].La trasformazione non &egrave; ammessa quando i fatti che vi darebbero luogo sono considerati nell&#39;atto di fondazione come causa di estinzione della persona giuridica e di devoluzione dei beni a terze persone [31].Le disposizioni del primo comma di questo articolo e dell&#39;articolo 26 non si applicano alle fondazioni destinate a vantaggio soltanto di una o pi&ugrave; famiglie determinate. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo