﻿---
slug: art156bis
title: Art. 156 bis codice civile - Cognome della moglie - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo V - Dello scioglimento del matrimonio e della separazione dei coniugi (1)Il giudice pu&ograve; vietare alla moglie l&#39;uso del cognome del marito [143 bis], quando tale uso sia a lui gravemente pregiudizievole(2), e pu&ograve; parimenti autorizzare la moglie a non usare il cognome stesso, qualora dall&#39;uso possa derivarle grave pregiudizio. Art. precedenteprec. Art. successivosucc.