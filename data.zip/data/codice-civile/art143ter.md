﻿---
slug: art143ter
title: Art. 143 ter codice civile - Cittadinanza della moglie - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo IV - Dei diritti e dei doveri che nascono dal matrimonio Articolo abrogato dall&#39;art. 26 della L. 5 febbraio 1992, n. 91. &lsqb;La moglie conserva la cittadinanza italiana, salvo sua espressa rinunzia, anche se per effetto del matrimonio o del mutamento di cittadinanza da parte del marito assume una cittadinanza straniera.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni