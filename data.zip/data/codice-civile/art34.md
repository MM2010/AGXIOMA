﻿---
slug: art34
title: Art. 34 codice civile - Registrazione di atti - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Abrogato dall&#39; art. 11, lett. a), d.P.R. 10 febbraio 2000, n. 361. &lsqb;Nel registro devono iscriversi anche le modificazioni dell&#39;atto costitutivo e dello statuto, dopo che sono state approvate dall&#39;autorit&agrave; governativa, il trasferimento della sede e l&#39;istituzione di sedi secondarie, la sostituzione degli amministratori con indicazione di quelli ai quali spetta la rappresentanza, le deliberazioni di scioglimento, i provvedimenti che ordinano lo scioglimento o dichiarano l&#39;estinzione, il cognome e il nome dei liquidatori.Se l&#39;iscrizione non ha avuto luogo, i fatti indicati non possono essere opposti ai terzi, a meno che si provi che questi ne erano a conoscenza.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni