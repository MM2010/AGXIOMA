﻿---
slug: art1
title: Art. 1 codice civile - Capacità giuridica - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo I - Delle persone fisiche La capacit&agrave; giuridica si acquista dal momento della nascita [22 Cost.].I diritti che la legge riconosce a favore del concepito sono subordinati all&#39;evento della nascita(1)(2). Art. successivosucc.