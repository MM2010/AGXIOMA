﻿---
slug: art32
title: Art. 32 codice civile - Devoluzione dei beni con destinazione particolare - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Nel caso di trasformazione o di scioglimento di un ente, al quale sono stati donati o lasciati beni con destinazione a scopo diverso da quello proprio dell&#39;ente, l&#39;autorit&agrave; governativa devolve tali beni, con lo stesso onere, ad altre persone giuridiche che hanno fini analoghi. Art. precedenteprec. Art. successivosucc. Scarica in PDF