﻿---
slug: art155ter
title: Art. 155 ter codice civile - Revisione delle disposizioni concernenti l'affidamento dei figli - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo V - Dello scioglimento del matrimonio e della separazione dei coniugi Articolo abrogato dal D.lgs. 28 dicembre 2013, n. 154. &lsqb;I genitori hanno diritto di chiedere in ogni tempo la revisione delle disposizioni concernenti l&#39;affidamento dei figli, l&#39;attribuzione dell&#39;esercizio della potest&agrave; su di essi e delle eventuali disposizioni relative alla misura e alla modalita del contributo.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni