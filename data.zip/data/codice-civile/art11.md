﻿---
slug: art11
title: Art. 11 codice civile - Persone giuridiche pubbliche - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo I - Disposizioni generali Le province e i comuni, nonch&eacute; gli enti pubblici riconosciuti come persone giuridiche godono dei diritti secondo le leggi e gli usi osservati come diritto pubblico. Art. precedenteprec. Art. successivosucc. Scarica in PDF