﻿---
slug: art2
title: Art. 2 codice civile - Maggiore età. Capacità di agire - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo I - Delle persone fisiche La maggiore et&agrave; &egrave; fissata al compimento del diciottesimo anno. Con la maggiore et&agrave; si acquista la capacit&agrave; di compiere tutti gli atti per i quali non sia stabilita un&#39;et&agrave; diversa(1).Sono salve le leggi speciali che stabiliscono un&#39;et&agrave; inferiore in materia di capacit&agrave; a prestare il proprio lavoro. In tal caso il minore &egrave; abilitato all&#39;esercizio dei diritti e delle azioni che dipendono dal contratto di lavoro(2). Art. precedenteprec. Art. successivosucc.