﻿---
slug: art337septies
title: Art. 337 septies codice civile - Disposizioni in favore dei figli maggiorenni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX - Della responsabilità genitoriale e dei diritti e doveri del figlio &rarr; Capo II - Esercizio della responsabilità genitoriale a seguito di separazione, scioglimento, cessazione degli effetti civili, annullamento, nullità del matrimonio ovvero all'esito di procedimenti relativi ai figli nati fuori del matrimonio (1)Il giudice, valutate le circostanze, pu&ograve; disporre in favore dei figli maggiorenni non indipendenti economicamente il pagamento di un assegno periodico. Tale assegno, salvo diversa determinazione del giudice, &egrave; versato direttamente all&#39;avente diritto.Ai figli maggiorenni portatori di handicap grave si applicano integralmente le disposizioni previste in favore dei figli minori. Art. precedenteprec. Art. successivosucc.