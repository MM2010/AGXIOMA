﻿---
slug: art243bis
title: Art. 243 bis codice civile - Disconoscimento di paternità - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VII - Dello stato di figlio &rarr; Capo II - Delle prove della filiazione (1)L&#39;azione di disconoscimento di paternit&agrave; del figlio nato nel matrimonio pu&ograve; essere esercitata dal marito, dalla madre e dal figlio medesimo.Chi esercita l&#39;azione &egrave; ammesso a provare che non sussiste rapporto di filiazione tra il figlio e il presunto padre.La sola dichiarazione della madre non esclude la paternit&agrave;. Art. precedenteprec. Art. successivosucc.