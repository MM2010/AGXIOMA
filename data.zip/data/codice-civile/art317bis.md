﻿---
slug: art317bis
title: Art. 317 bis codice civile - Rapporti con gli ascendenti - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX - Della responsabilità genitoriale e dei diritti e doveri del figlio &rarr; Capo I - Dei diritti e doveri del figlio (1)Gli ascendenti hanno diritto di mantenere rapporti significativi con i nipoti minorenni.L&#39;ascendente al quale &egrave; impedito l&#39;esercizio di tale diritto pu&ograve; ricorrere al giudice del luogo di residenza abituale del minore affinch&egrave; siano adottati i provvedimenti pi&ugrave; idonei nell&#39;esclusivo interesse del minore. Si applica l&#39;articolo 336, secondo comma. Art. precedenteprec. Art. successivosucc.