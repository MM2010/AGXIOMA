﻿---
slug: art155sexies
title: Art. 155 sexies codice civile - Poteri del giudice e ascolto del minore - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo V - Dello scioglimento del matrimonio e della separazione dei coniugi Articolo abrogato dal D.lgs. 28 dicembre 2013, n. 154. &lsqb;Prima dell&#39;emanazione, anche in via provvisoria, dei provvedimenti di cui all&#39;articolo 155, il giudice pu&ograve; assumere, ad istanza di parte o d&#39;ufficio, mezzi di prova. Il giudice dispone, inoltre, l&#39;audizione del figlio minore che abbia compiuto gli anni dodici e anche di et&agrave; inferiore ove capace di discernimento.Qualora ne ravvisi l&#39;opportunit&agrave;, il giudice, sentite le parti e ottenuto il loro consenso, pu&ograve; rinviare l&#39;adozione dei provvedimenti di cui all&#39;articolo 155 per consentire che i coniugi, avvalendosi di esperti, tentino una mediazione per raggiungere un accordo, con particolare riferimento alla tutela dell&#39;interesse morale e materiale dei figli.&rsqb; Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo Relazioni