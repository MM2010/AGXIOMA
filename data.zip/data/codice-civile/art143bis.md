﻿---
slug: art143bis
title: Art. 143 bis codice civile - Cognome della moglie - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo IV - Dei diritti e dei doveri che nascono dal matrimonio La moglie aggiunge al proprio cognome quello del marito(1) e lo conserva durante lo stato vedovile, fino a che passi a nuove nozze [156 bis, 328]. Art. precedenteprec. Art. successivosucc.