﻿---
slug: art3
title: Art. 3 codice civile - Capacità in materia di lavoro - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo I - Delle persone fisiche Art. abrogato ex art. 2, l. 8-3-1975, n. 39, attribuzione della maggiore et&agrave;. &lsqb;Il minore che ha compiuto gli anni diciotto pu&ograve; prestare il proprio lavoro, stipulare i relativi contratti ed esercitare i diritti e le azioni che ne dipendono, salve le leggi speciali che stabiliscono un&#39;et&agrave; inferiore.&rsqb; Art. precedenteprec. Art. successivosucc.