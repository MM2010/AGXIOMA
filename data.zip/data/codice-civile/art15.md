﻿---
slug: art15
title: Art. 15 codice civile - Revoca dell'atto costitutivo della fondazione - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni L&#39;atto di fondazione pu&ograve; essere revocato dal fondatore fino a quando non sia intervenuto il riconoscimento ovvero il fondatore non abbia fatto iniziare l&#39;attivit&agrave; dell&#39;opera da lui disposta [555, 786, 2331].La facolt&agrave; di revoca non si trasmette agli eredi. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo