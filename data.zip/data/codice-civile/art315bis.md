﻿---
slug: art315bis
title: Art. 315 bis codice civile - Diritti e doveri del figlio - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX - Della responsabilità genitoriale e dei diritti e doveri del figlio &rarr; Capo I - Dei diritti e doveri del figlio Il figlio ha diritto di essere mantenuto, educato, istruito e assistito moralmente dai genitori, nel rispetto delle sue capacit&agrave;, delle sue inclinazioni naturali e delle sue aspirazioni.Il figlio ha diritto di crescere in famiglia e di mantenere rapporti significativi con i parenti.Il figlio minore che abbia compiuto gli anni dodici, e anche di et&agrave; inferiore ove capace di discernimento, ha diritto di essere ascoltato in tutte le questioni e le procedure che lo riguardano.Il figlio deve rispettare i genitori e deve contribuire, in relazione alle proprie capacit&agrave;, alle proprie sostanze e al proprio reddito, al mantenimento della famiglia finch&eacute; convive con essa(1). Art. precedenteprec. Art. successivosucc.