﻿---
slug: art30
title: Art. 30 codice civile - Liquidazione - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Dichiarata l&#39;estinzione della persona giuridica [27] o disposto lo scioglimento dell&#39;associazione, si procede alla liquidazione del patrimonio secondo le norme di attuazione del codice [31]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo