﻿---
slug: art166bis
title: Art. 166 bis codice civile - Divieto di costituzione di dote - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo VI - Del matrimonio &rarr; Capo VI - Del regime patrimoniale della famiglia &rarr; Sezione I - Disposizioni generali (1)&Egrave; nulla(2) ogni convenzione che comunque tenda alla costituzione di beni in dote(3). Art. precedenteprec. Art. successivosucc.