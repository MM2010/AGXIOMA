﻿---
slug: art21
title: Art. 21 codice civile - Deliberazioni dell'assemblea - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Le deliberazioni dell&#39;assemblea sono prese a maggioranza di voti e con la presenza di almeno la met&agrave; degli associati. In seconda convocazione la deliberazione &egrave; valida qualunque sia il numero degli intervenuti. Nelle deliberazioni di approvazione del bilancio e in quelle che riguardano la loro responsabilit&agrave; [18, 22] gli amministratori non hanno voto.Per modificare l&#39;atto costitutivo e lo statuto, se in essi non &egrave; altrimenti disposto, occorrono la presenza di almeno tre quarti degli associati e il voto favorevole della maggioranza dei presenti [16].Per deliberare lo scioglimento dell&#39;associazione e la devoluzione del patrimonio [31 ss.] occorre il voto favorevole di almeno tre quarti degli associati [11]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo