﻿---
slug: art29
title: Art. 29 codice civile - Divieto di nuove operazioni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Gli amministratori non possono compiere nuove operazioni, appena &egrave; stato loro comunicato il provvedimento che dichiara l&#39;estinzione della persona giuridica [27] o il provvedimento con cui l&#39;autorit&agrave;, a norma di legge, ha ordinato lo scioglimento dell&#39;associazione, o appena &egrave; stata adottata dall&#39;assemblea la deliberazione di scioglimento dell&#39;associazione medesima [21]. Qualora trasgrediscano a questo divieto, assumono responsabilit&agrave; personale e solidale [18]. Art. precedenteprec. Art. successivosucc. Scarica in PDF Dispositivo