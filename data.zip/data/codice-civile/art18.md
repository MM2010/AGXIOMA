﻿---
slug: art18
title: Art. 18 codice civile - Responsabilità degli amministratori - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Gli amministratori sono responsabili verso l&#39;ente secondo le norme del mandato(1). &Egrave; per&ograve; esente da responsabilit&agrave; quello degli amministratori il quale non abbia partecipato all&#39;atto che ha causato il danno, salvo il caso in cui, essendo a cognizione che l&#39;atto si stava per compiere, egli non abbia fatto constare il proprio dissenso. Art. precedenteprec. Art. successivosucc.