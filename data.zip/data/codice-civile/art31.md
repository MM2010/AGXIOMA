﻿---
slug: art31
title: Art. 31 codice civile - Devoluzione dei beni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni I beni della persona giuridica, che restano dopo esaurita la liquidazione [30], sono devoluti in conformit&agrave; dell&#39;atto costitutivo o dello statuto [16; 15].Qualora questi non dispongano, se trattasi di fondazione, provvede l&#39;autorit&agrave; governativa, attribuendo i beni ad altri enti che hanno fini analoghi [32]; se trattasi di associazione, si osservano le deliberazioni dell&#39;assemblea che ha stabilito lo scioglimento e, quando anche queste mancano, provvede nello stesso modo l&#39;autorit&agrave; governativa.I creditori che durante la liquidazione non hanno fatto valere il loro credito possono chiedere il pagamento a coloro ai quali i beni sono stati devoluti, entro l&#39;anno dalla chiusura della liquidazione(1), in proporzione e nei limiti di ci&ograve; che hanno ricevuto. Art. precedenteprec. Art. successivosucc.