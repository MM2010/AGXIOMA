﻿---
slug: art27
title: Art. 27 codice civile - Estinzione della persona giuridica - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Oltre che per le cause previste nell&#39;atto costitutivo e nello statuto [16], la persona giuridica si estingue quando lo scopo &egrave; stato raggiunto o &egrave; divenuto impossibile [28, 2272 n. 2, 2484, n. 2] .Le associazioni si estinguono inoltre quando tutti gli associati sono venuti a mancare [2272 n. 4].[L&#39;estinzione &egrave; dichiarata dalla autorit&agrave; governativa, su istanza di qualunque interessato o anche di ufficio](1). Art. precedenteprec. Art. successivosucc.