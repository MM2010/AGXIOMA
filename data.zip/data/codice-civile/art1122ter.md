﻿---
slug: art1122ter
title: Art. 1122 ter codice civile - Impianti di videosorveglianza sulle parti comuni - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO TERZO - Della proprietà &rarr; Titolo VII - Della comunione &rarr; Capo II - Del condominio negli edifici (1)Le deliberazioni concernenti l&#39;installazione sulle parti comuni dell&#39;edificio di impianti volti a consentire la videosorveglianza(2) su di esse sono approvate dall&#39;assemblea con la maggioranza di cui al secondo comma dell&#39;articolo 1136(3). Art. precedenteprec. Art. successivosucc.