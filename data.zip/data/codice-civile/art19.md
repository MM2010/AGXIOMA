﻿---
slug: art19
title: Art. 19 codice civile - Limitazioni del potere di rappresentanza - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Le limitazioni del potere di rappresentanza, che non risultano dal registro indicato nell&#39;articolo 33(1), non possono essere opposte ai terzi, salvo che si provi che essi ne erano a conoscenza. Art. precedenteprec. Art. successivosucc.