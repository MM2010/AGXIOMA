﻿---
slug: art1117bis
title: Art. 1117 bis codice civile - Ambito di applicabilità - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO TERZO - Della proprietà &rarr; Titolo VII - Della comunione &rarr; Capo II - Del condominio negli edifici (1)Le disposizioni del presente capo si applicano, in quanto compatibili, in tutti i casi in cui pi&ugrave; unit&agrave; immobiliari o pi&ugrave; edifici ovvero pi&ugrave; condominii di unit&agrave; immobiliari o di edifici abbiano parti comuni ai sensi dell&#39;articolo 1117(2). Art. precedenteprec. Art. successivosucc.