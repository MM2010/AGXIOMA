﻿---
slug: art35
title: Art. 35 codice civile - Disposizione penale - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Gli amministratori e i liquidatori che non richiedono le iscrizioni prescritte [dagli articoli 33 e 34, nel termine e secondo le modalit&agrave; stabiliti dalle norme di attuazione del codice](1), sono puniti con la sanzione amministrativa da euro 10 a euro 516(2). Art. precedenteprec. Art. successivosucc.