﻿---
slug: art22
title: Art. 22 codice civile - Azioni di responsabilità contro gli amministratori - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo II - Delle persone giuridiche &rarr; Capo II - Delle associazioni e delle fondazioni Le azioni di responsabilit&agrave;(1) contro gli amministratori delle associazioni per fatti da loro compiuti sono deliberate dall&#39;assemblea [21] e sono esercitate dai nuovi amministratori o dai liquidatori. Art. precedenteprec. Art. successivosucc.