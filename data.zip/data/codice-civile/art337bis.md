﻿---
slug: art337bis
title: Art. 337 bis codice civile - Ambito di applicazione - Brocardi.it
category: codi
---

Fonti &rarr; Codice Civile &rarr; LIBRO PRIMO - Delle persone e della famiglia &rarr; Titolo IX - Della responsabilità genitoriale e dei diritti e doveri del figlio &rarr; Capo II - Esercizio della responsabilità genitoriale a seguito di separazione, scioglimento, cessazione degli effetti civili, annullamento, nullità del matrimonio ovvero all'esito di procedimenti relativi ai figli nati fuori del matrimonio (1)In caso di separazione, scioglimento, cessazione degli effetti civili, annullamento, nullit&agrave; del matrimonio e nei procedimenti relativi ai figli nati fuori del matrimonio si applicano le disposizioni del presente capo. Art. precedenteprec. Art. successivosucc.